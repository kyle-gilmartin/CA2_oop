﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CA2
{  public enum typeofactiv {Land,Air,Water}
    class Activity:IComparable<Activity>
    {
        private decimal _price;
        public string Activ { get; set; }
        public DateTime DateTime { get; set; }
        public decimal Price
        {
            get { return _price;}
            set
            {
                TotalAmount += value;
                _price = value;
            }
        }

        public static decimal TotalAmount;
        public typeofactiv RadiobuttonTypeofactiv { get; set; }
        public string Description { get; set; }
       
       

       





        public Activity(string activ,DateTime date, decimal price , typeofactiv radiobuttonTypeofactiv , string description)
        {
            Activ = activ;
            DateTime = date;
            Price = price;
            RadiobuttonTypeofactiv = radiobuttonTypeofactiv;
            Description = description;
        }


        public override string ToString()
        {
            return $"{Activ}\t{DateTime.ToShortDateString()}";
        }

        

        public string GetDetails()
        {
            return $"{Description}";
        }

        public int CompareTo(Activity other)
        {
            return this.DateTime.CompareTo(other.DateTime);
        }
    }
}
