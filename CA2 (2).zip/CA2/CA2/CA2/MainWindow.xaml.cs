﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace CA2
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window 
    {
     List<Activity> allActivities =new List<Activity>();
     List<Activity> selectedActivities = new List<Activity>();
     List<Activity> filterActivities = new List<Activity>();

     public decimal totalPrice = 0;

        public MainWindow()
        {
            InitializeComponent();


        }

        public void Window_Loaded(object sender, RoutedEventArgs e)
        {
           

            Activity e1 = new Activity("Bike",new DateTime(2019,12,03),500.00m, typeofactiv.Land,  "Bike");
            Activity e2 = new Activity("Car", new DateTime(2019,02,23), 800.00m, typeofactiv.Land, "car");
            Activity e3 = new Activity("Boat", new DateTime(2013,06,23), 100.00m, typeofactiv.Water, "boat");
            Activity e4 = new Activity("Sub", new DateTime(2015, 10, 27), 400.00m, typeofactiv.Water, "Sub");
            Activity e5 = new Activity("Plane", new DateTime(2013, 06, 23), 900.00m, typeofactiv.Air, "Planes ");
            Activity e6 = new Activity("Jet", new DateTime(2020, 09, 30), 500.00m, typeofactiv.Air, "Jet");



            // add to list
            allActivities.Add(e1);
            allActivities.Add(e2);
            allActivities.Add(e3);
            allActivities.Add(e4);
            allActivities.Add(e5);
            allActivities.Add(e6);

            allActivities.Sort();


            //Display list

            LbxAcivities_LeftList.ItemsSource = allActivities;


            //TblTotal.Content = Activity.TotalAmount.;

        }

        

        private void AddButton_Click(object sender, RoutedEventArgs e)
        {

            var selectedActivity = LbxAcivities_LeftList.SelectedItem as Activity;

            if (selectedActivity != null)
            {
                allActivities.Remove(selectedActivity);
                selectedActivities.Add(selectedActivity);

                //update total
                totalPrice += selectedActivity.Price;
                TblTotal.Content =  totalPrice;



                RefreshScreen();

                
            }


        }


       

        private void TakeawayButton_Click(object sender, RoutedEventArgs e)
        {
            var selectedActivity = LbxSelectedActivities_RightList.SelectedItem as Activity;

            if (selectedActivity != null)
            {
                allActivities.Add(selectedActivity);
                selectedActivities.Remove(selectedActivity);

                //take from total
                totalPrice -= selectedActivity.Price;
                TblTotal.Content = totalPrice;

                RefreshScreen();
            }

        }

        private void RefreshScreen()  
        {
            LbxAcivities_LeftList.ItemsSource = null;
            LbxAcivities_LeftList.ItemsSource = allActivities;

            LbxSelectedActivities_RightList.ItemsSource = null;
            LbxSelectedActivities_RightList.ItemsSource = selectedActivities;
        }

        private void LbxAcivities_LeftList_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            
            //find out what was selected
            Activity selectedActivity = LbxAcivities_LeftList.SelectedItem as Activity;
            
            //make sure it's not null
            if (selectedActivity != null)
            {
                tblkDescription.Content = selectedActivity.GetDetails();
            }

            //update text
        }

        private void LbxSelectedActivities_RightList_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            
            //find out what was selected
            Activity selectedActivity = LbxSelectedActivities_RightList.SelectedItem as Activity;

            //make sure it's not null
            if (selectedActivity != null)
            {
                tblkDescription.Content = selectedActivity.GetDetails();
            }
        }





        private void RbAll_Click(object sender, RoutedEventArgs e)
        {
            filterActivities.Clear();

            if (RbAll.IsChecked == true)
            {
                RefreshScreen();
            }

            else if (RbLand.IsChecked == true)
            {
                foreach (Activity activity in allActivities)
                {
                    if (activity.RadiobuttonTypeofactiv == typeofactiv.Land)
                    {
                        filterActivities.Add(activity);
                        LbxAcivities_LeftList.ItemsSource = null;
                        LbxAcivities_LeftList.ItemsSource = filterActivities;
                    }
                }
            }

            else if (RbAir.IsChecked == true)
            {
                foreach (Activity activity in allActivities)
                {
                    if (activity.RadiobuttonTypeofactiv == typeofactiv.Air)
                    {
                        filterActivities.Add(activity);
                        LbxAcivities_LeftList.ItemsSource = null;
                        LbxAcivities_LeftList.ItemsSource = filterActivities;
                    }
                }
            }

            else if (RbWater.IsChecked == true)
            {
                foreach (Activity activity in allActivities)
                {
                    if (activity.RadiobuttonTypeofactiv == typeofactiv.Water)
                    {
                        filterActivities.Add(activity);
                        LbxAcivities_LeftList.ItemsSource = null;
                        LbxAcivities_LeftList.ItemsSource = filterActivities;
                    }
                }
            }
        }

        
    }
    
}
